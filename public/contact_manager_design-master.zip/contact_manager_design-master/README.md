# Simple Contact Manager

This is simple contact manager application
